#ifndef VSF_IRIX_BOGONS_H
#define VSF_IRIX_BOGONS_H

/* Need dirfd() */
#include "dirfd_extras.h"

#endif /* VSF_IRIX_BOGONS_H */

